<script src="<?php echo base_url('assets/js/jquery-2.1.1.js') ?>"></script>
    <script src="<?php echo base_url('assets/js/bootstrap.min.js') ?>"></script>
    <script src="<?php echo base_url('assets/js/plugins/metisMenu/jquery.metisMenu.js') ?>"></script>
    <script src="<?php echo base_url('assets/js/plugins/slimscroll/jquery.slimscroll.min.js') ?>"></script>

    <!-- Flot -->
    <script src="<?php echo base_url('assets/js/plugins/flot/jquery.flot.js') ?>"></script>
    <script src="<?php echo base_url('assets/js/plugins/flot/jquery.flot.tooltip.min.js') ?>"></script>
    <script src="<?php echo base_url('assets/js/plugins/flot/jquery.flot.spline.js') ?>"></script>
    <script src="<?php echo base_url('assets/js/plugins/flot/jquery.flot.resize.js') ?>"></script>
    <script src="<?php echo base_url('assets/js/plugins/flot/jquery.flot.pie.js') ?>"></script>
    <script src="<?php echo base_url('assets/js/plugins/flot/jquery.flot.symbol.js') ?>"></script>
    <script src="<?php echo base_url('assets/js/plugins/flot/curvedLines.js') ?>"></script>

    <!-- Peity -->
    <script src="<?php echo base_url('assets/js/plugins/peity/jquery.peity.min.js') ?>"></script>
    <script src="<?php echo base_url('assets/js/demo/peity-demo.js') ?>"></script>

    <!-- Custom and plugin javascript -->
    <script src="<?php echo base_url('assets/js/inspinia.js') ?>"></script>
    <script src="<?php echo base_url('assets/js/plugins/pace/pace.min.js') ?>"></script>

    <!-- jQuery UI -->
    <script src="<?php echo base_url('assets/js/plugins/jquery-ui/jquery-ui.min.js') ?>"></script>

    <!-- Jvectormap -->
    <script src="<?php echo base_url('assets/js/plugins/jvectormap/jquery-jvectormap-2.0.2.min.js') ?>"></script>
    <script src="<?php echo base_url('assets/js/plugins/jvectormap/jquery-jvectormap-world-mill-en.js') ?>"></script>

    <!-- Sparkline -->
    <script src="<?php echo base_url('assets/js/plugins/sparkline/jquery.sparkline.min.js') ?>"></script>

    <!-- Sparkline demo data  -->
    <script src="<?php echo base_url('assets/js/demo/sparkline-demo.js') ?>"></script>

    <!-- ChartJS-->
    <script src="<?php echo base_url('assets/js/plugins/chartJs/Chart.min.js') ?>"></script>

    <script src="<?php echo base_url('assets/js/plugins/chartist/chartist.min.js') ?>"></script>
